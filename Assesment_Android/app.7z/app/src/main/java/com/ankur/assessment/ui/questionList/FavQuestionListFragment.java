package com.ankur.assessment.ui.questionList;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.ankur.assessment.R;
import com.ankur.assessment.common.BaseFragment;
import com.ankur.assessment.model.Item;
import com.ankur.assessment.ui.questionList.adapter.FavQuestinListAdapter;
import com.ankur.assessment.ui.questionList.adapter.QuestionListAdapter;
import com.ankur.assessment.ui.questionList.presenter.QuestionListPresenter;
import com.ankur.assessment.util.DividerItemDecoration;
import com.ankur.assessment.view.CustomRecyclerViewWithFooter;

import java.util.ArrayList;

import butterknife.BindView;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link FavQuestionListFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class FavQuestionListFragment extends BaseFragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private int mParam2;

    @BindView(R.id.rv_questionList)
    CustomRecyclerViewWithFooter rvQuestionList;

    private QuestionListPresenter mPresenter;
    private ArrayList<Item> mQuestionArrayList;
    private int mFragmentPosition;

    private String mOrderType = "";
    private String mSortType = "";
    private LinearLayoutManager rvLayoutManager;
    private FavQuestinListAdapter mRecyclerViewAdapter;

    private boolean mLoadNext;

    public FavQuestionListFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param questionList   Parameter 1.
     * @param typeOfFragment Parameter 2.
     * @return A new instance of fragment FavQuestionListFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static FavQuestionListFragment newInstance(ArrayList<Item> questionList, int typeOfFragment) {
        FavQuestionListFragment fragment = new FavQuestionListFragment();
        Bundle args = new Bundle();
        args.putParcelableArrayList(ARG_PARAM1, questionList);
        args.putInt(ARG_PARAM2, typeOfFragment);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mQuestionArrayList = getArguments().getParcelableArrayList(ARG_PARAM1);
            mParam2 = getArguments().getInt(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        setLayout(inflater, R.layout.fragment_question_list);

        setUpRecyclerView();
        return mBaseFragmentContainer;
    }

    private void setUpRecyclerView() {

        mRecyclerViewAdapter = new FavQuestinListAdapter(getActivity(), mQuestionArrayList);
        RecyclerView.ItemDecoration dividerItemDecoration = new DividerItemDecoration(ContextCompat.getDrawable(getActivity(), R.drawable.recycler_divider));
        rvQuestionList.addItemDecoration(dividerItemDecoration);
        rvLayoutManager = new LinearLayoutManager(getActivity());
        rvQuestionList.setLayoutManager(rvLayoutManager);
        rvQuestionList.setAdapter(mRecyclerViewAdapter);

    }


    public void updateList(ArrayList<Item> updatedQuestionList) {
        if(updatedQuestionList!=null){
            hidePageLoading();
            mQuestionArrayList.clear();
            mQuestionArrayList.addAll(updatedQuestionList);
            mRecyclerViewAdapter.notifyDataSetChanged();
        }
    }
}
