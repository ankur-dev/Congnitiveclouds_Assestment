package com.ankur.assessment.ui.questionList;

import android.app.SearchManager;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;

import com.ankur.assessment.R;
import com.ankur.assessment.interfaces.AdapterToActivityListener;
import com.ankur.assessment.model.Item;
import com.ankur.assessment.ui.questionList.adapter.QuestionListPagerAdapter;
import com.ankur.assessment.ui.questionList.presenter.QuestionListPresenter;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class QuestionsListActivity extends AppCompatActivity implements AdapterToActivityListener, ViewPager.OnPageChangeListener {

    @BindView(R.id.toolbar)
    Toolbar mToolbar;
    @BindView(R.id.tabs)
    TabLayout mTabs;
    @BindView(R.id.view_pager)
    ViewPager mViewPager;
    private ArrayList<Item> mQuestionArrayList;

    private QuestionListPresenter mPresenter;
    private QuestionListPagerAdapter mPagerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questions_list);
        ButterKnife.bind(this);

        // setUpToolBar

        setUpToolBar();

        mPagerAdapter = new QuestionListPagerAdapter(getSupportFragmentManager());
        mViewPager.setAdapter(mPagerAdapter);
        mTabs.setupWithViewPager(mViewPager);

        mViewPager.addOnPageChangeListener(this);

        mQuestionArrayList = new ArrayList<>();

    }

    private void setUpToolBar() {
        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle(R.string.title_activity_question_list);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.home, menu);
        // Retrieve the SearchView and plug it into SearchManager
        final SearchView searchView = (SearchView) MenuItemCompat.getActionView(menu.findItem(R.id.action_search));
        SearchManager searchManager = (SearchManager) getSystemService(SEARCH_SERVICE);
        searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
        return true;
    }

    @Override
    public void saveFavQuestionIntoDataBase(Item item) {
        item.save();
    }

    @Override
    public void deleteFavQuestionFromDataBase(Item item) {
        Item.deleteItemById(item.getId());
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {

        if(position==1){
            Fragment fragment = mPagerAdapter.getRegisteredFragment(1);
            if(fragment instanceof FavQuestionListFragment){
                Item item = new Item();
                ArrayList<Item> itemArrayList = new ArrayList<>();
                if(item.getFavQuestionListFromDataBase()!=null){
                    itemArrayList.addAll(item.getFavQuestionListFromDataBase());
                }
                ((FavQuestionListFragment) fragment).updateList(itemArrayList);
            }
        }
    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }
}
