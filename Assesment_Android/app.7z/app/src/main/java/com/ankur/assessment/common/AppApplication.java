package com.ankur.assessment.common;

import android.app.Application;

import com.activeandroid.ActiveAndroid;
import com.activeandroid.Configuration;
import com.ankur.assessment.model.Item;
import com.ankur.assessment.model.Owner;

/**
 * Created by Ankur on 12/1/2016.
 */

public class AppApplication extends Application {

    private AppApplication mApplicationContext;

    public AppApplication getApplicationContext() {
        return mApplicationContext;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mApplicationContext = this;

        // Initialized Active Android
        initializedActiveAndroid();


    }

    private void initializedActiveAndroid() {
        Configuration.Builder configurationBuilder = new Configuration.Builder(getApplicationContext());
        configurationBuilder.addModelClass(Item.class);
        configurationBuilder.addModelClass(Owner.class);
        ActiveAndroid.initialize(configurationBuilder.create());
    }
}
