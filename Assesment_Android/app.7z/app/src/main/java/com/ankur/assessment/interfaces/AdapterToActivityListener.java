package com.ankur.assessment.interfaces;

import com.ankur.assessment.model.Item;

/**
 * Created by Ankur on 12/2/2016.
 */

public interface AdapterToActivityListener {

    void saveFavQuestionIntoDataBase(Item item);

    void deleteFavQuestionFromDataBase(Item item);
}
