package com.ankur.assessment.network;

/**
 * Created by Ankur on 3/12/2016.
 */

public class NetworkUtils {

   public static final String BASE_URL = "https://api.stackexchange.com/2.2/";
   public static final String UNANSWERED_QUESTION = "/questions/unanswered";


}
