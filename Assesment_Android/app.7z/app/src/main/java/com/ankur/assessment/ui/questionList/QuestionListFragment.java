package com.ankur.assessment.ui.questionList;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.ankur.assessment.R;
import com.ankur.assessment.common.BaseFragment;
import com.ankur.assessment.model.Item;

import com.ankur.assessment.ui.questionList.adapter.QuestionListAdapter;
import com.ankur.assessment.ui.questionList.presenter.QuestionListPresenter;
import com.ankur.assessment.ui.questionList.view.QuestionListView;
import com.ankur.assessment.util.DividerItemDecoration;
import com.ankur.assessment.util.LogUtil;
import com.ankur.assessment.view.CustomRecyclerViewWithFooter;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link QuestionListFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class QuestionListFragment  extends BaseFragment implements QuestionListView {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    @BindView(R.id.rv_questionList)
    CustomRecyclerViewWithFooter rvQuestionList;
    @BindView(R.id.tv_noNetworkText)
    TextView tvNoNetworkText;
    @Nullable
    @BindView(R.id.no_network_strip)
    RelativeLayout noNetworkStrip;
    @BindView(R.id.no_internetContent)
    RelativeLayout mNoInternetView;

    private QuestionListPresenter mPresenter;
    private ArrayList<Item> mQuestionArrayList;
    private int mFragmentPosition;

    private String mOrderType ="";
    private String mSortType ="";
    private LinearLayoutManager rvLayoutManager;
    private QuestionListAdapter mRecyclerViewAdapter;

    private boolean mLoadNext;


    public QuestionListFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param questionList  question List .
     * @param fragmentIndex type of fragment.
     * @return A new instance of fragment QuestionListFragment.
     */
    public static QuestionListFragment newInstance(ArrayList<Item> questionList, int fragmentIndex) {
        QuestionListFragment fragment = new QuestionListFragment();
        Bundle args = new Bundle();
        args.putParcelableArrayList(ARG_PARAM1, questionList);
        args.putInt(ARG_PARAM2, fragmentIndex);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mQuestionArrayList = getArguments().getParcelableArrayList(ARG_PARAM1);
            mFragmentPosition = getArguments().getInt(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        super.onCreateView(inflater, container, savedInstanceState);
        setLayout(inflater, R.layout.fragment_question_list);

        setUpRecyclerView();
        mPresenter = new QuestionListPresenter(getActivity(), this);
        mOrderType = "desc";
        mSortType = "creation";
        mPresenter.getQuestionListFromServer(mOrderType, mSortType);



        return mBaseFragmentContainer;
    }

    private void setUpRecyclerView() {

        mRecyclerViewAdapter = new QuestionListAdapter(getActivity(),mQuestionArrayList);
        RecyclerView.ItemDecoration dividerItemDecoration = new DividerItemDecoration(ContextCompat.getDrawable(getActivity(), R.drawable.recycler_divider));
        rvQuestionList.addItemDecoration(dividerItemDecoration);
        rvLayoutManager = new LinearLayoutManager(getActivity());
        rvQuestionList.setLayoutManager(rvLayoutManager);
        rvQuestionList.setAdapter(mRecyclerViewAdapter);

        rvQuestionList.addOnScrollListener(new RecyclerView.OnScrollListener() {

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy)   {
                int  visibleItemCount, totalItemCount;
                int pastVisibleItem = 0;
                if (dy > 0) {/*check for scroll down*/
                    visibleItemCount = rvLayoutManager.getChildCount();
                    totalItemCount = rvLayoutManager.getItemCount();
                    pastVisibleItem = rvLayoutManager.findFirstVisibleItemPosition();

                    if (mLoadNext) {//Check to load next page
                        if ((visibleItemCount + pastVisibleItem) >= totalItemCount) {
                            mPresenter.loadMore();
                            mLoadNext = false;
                        }
                    }
                }
            }
        });
    }


    @Override
    public void addToQuestionList(ArrayList<Item> itemArrayList) {

        if(itemArrayList!=null){
            mRecyclerViewAdapter.mQuestionList.addAll(itemArrayList);
            mRecyclerViewAdapter.notifyDataSetChanged();
            mLoadNext = true;
            LogUtil.d("ankur","dataa come");
        }
    }

    @Override
    public void showLazyPageLoading() {
        if(mQuestionArrayList!=null && mQuestionArrayList.size()>0){

        }
        else {
            showPageLoading();
        }
    }

    @Override
    public void hideLazyPageLoading() {
        if(mQuestionArrayList!=null && mQuestionArrayList.size()>0){

        }
        else {
            hidePageLoading();
        }
    }

    @OnClick(R.id.refresh_internet_button)
    public void onClick() {
        hideNoInternetLayout();
        mPresenter.getQuestionListFromServer(mOrderType,mSortType);
    }

    @Override
    public void showNoInternetView() {
        rvQuestionList.setVisibility(View.INVISIBLE);
        mNoInternetView.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideNoInternetLayout() {
        mNoInternetView.setVisibility(View.INVISIBLE);
        rvQuestionList.setVisibility(View.VISIBLE);
    }
}
