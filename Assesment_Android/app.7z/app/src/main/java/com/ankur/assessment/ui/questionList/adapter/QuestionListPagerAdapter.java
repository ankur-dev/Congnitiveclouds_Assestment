package com.ankur.assessment.ui.questionList.adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.ViewGroup;

import com.ankur.assessment.model.Item;
import com.ankur.assessment.ui.questionList.FavQuestionListFragment;
import com.ankur.assessment.ui.questionList.QuestionListFragment;

import java.util.ArrayList;

/**
 * Created by Ankur on 12/2/2016.
 */

public class QuestionListPagerAdapter extends SaveFragmentStatePagerAdapter{

    private final String[] TITLES = {"Questions","Fav"};
    private ArrayList<Item> questionArrayList = new ArrayList<>();

    public QuestionListPagerAdapter(FragmentManager fragmentManager) {
        super(fragmentManager);
        questionArrayList = new ArrayList<>();
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return TITLES[position];
    }

    @Override
    public int getCount() {
        return TITLES.length;
    }

    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                return QuestionListFragment.newInstance(questionArrayList,0);
            case 1:
                return FavQuestionListFragment.newInstance(questionArrayList,1);

        }
        return null;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        return super.instantiateItem(container, position);
    }
}
