package com.ankur.assessment.ui.questionList.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.ankur.assessment.R;
import com.ankur.assessment.interfaces.AdapterToActivityListener;
import com.ankur.assessment.model.Item;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by Ankur on 12/2/2016.
 */

public class QuestionListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public List<Item> mQuestionList;
    private Context mContext;
    private static final String DATE_FORMAT = "dd MMM, yyyy HH:mm";
    private AdapterToActivityListener mActivityListener;

    public QuestionListAdapter(Context context, @NonNull List<Item> items) {
        this.mQuestionList = items;
        mContext = context;
        mActivityListener = (AdapterToActivityListener) context;
    }


    public QuestionListAdapter setItems(List<Item> newItems) {
        mQuestionList.clear();
        mQuestionList.addAll(newItems);
        notifyDataSetChanged();
        return this;
    }

    public List<Item> getItems() {
        return mQuestionList;
    }

    public QuestionListAdapter addItems(List<Item> newItems) {
        //items.clear();
        mQuestionList.addAll(newItems);
        notifyDataSetChanged();
        return this;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.question_list_row_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder viewHolder, int position) {
        final ViewHolder customViewHolder = (ViewHolder) viewHolder;
        if (mQuestionList.get(position) != null) {
            setDataToTextView(customViewHolder.questionTitleTv, mQuestionList.get(position).getTitle());
            setDataToTextView(customViewHolder.timeStamp, getDataFormat(mQuestionList.get(position).getCreationDate()));
            setDataToTextView(customViewHolder.tagLine1, mQuestionList.get(position).getTags().toString());
            if (mQuestionList.get(position).getOwner() != null)
                setDataToTextView(customViewHolder.ratingValueTv, String.valueOf(mQuestionList.get(position).getOwner().getReputation()));

            if (mQuestionList.get(position).isFav()) {
                customViewHolder.likeButton.setBackgroundColor(ContextCompat.getColor(mContext, R.color.gery_color));
            } else {
                customViewHolder.likeButton.setBackgroundColor(ContextCompat.getColor(mContext, R.color.colorPrimary));
            }
        }
        customViewHolder.refPosition = position;
        customViewHolder.likeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mQuestionList.get(viewHolder.getAdapterPosition()).isFav()) {
                    mQuestionList.get(viewHolder.getAdapterPosition()).setFav(false);
                    customViewHolder.likeButton.setBackgroundColor(ContextCompat.getColor(mContext, R.color.gery_color));
                    mActivityListener.deleteFavQuestionFromDataBase(mQuestionList.get(customViewHolder.refPosition));
                    notifyDataSetChanged();
                } else {
                    mQuestionList.get(viewHolder.getAdapterPosition()).setFav(true);
                    customViewHolder.likeButton.setBackgroundColor(ContextCompat.getColor(mContext, R.color.colorPrimary));
                    mActivityListener.saveFavQuestionIntoDataBase(mQuestionList.get(customViewHolder.refPosition));
                    notifyDataSetChanged();
                }
            }
        });
    }


    @Override
    public int getItemCount() {
        return mQuestionList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.time_stamp)
        TextView timeStamp;
        @BindView(R.id.user_image)
        ImageView userImage;
        @BindView(R.id.question_title_tv)
        TextView questionTitleTv;
        @BindView(R.id.tagLine1)
        TextView tagLine1;
        @BindView(R.id.rating_value_tv)
        TextView ratingValueTv;
        @BindView(R.id.like_button)
        Button likeButton;
        @BindView(R.id.share_button)
        Button shareButton;

        int refPosition;

        ViewHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);
        }
    }


    private void setDataToTextView(TextView textView, String dataString) {
        if (!TextUtils.isEmpty(dataString))
            textView.setText(dataString);

    }


    private String getDataFormat(long timeStamp) {
        String dateString = "";
        Date date = new Date(timeStamp * 1000);
        @SuppressLint("SimpleDateFormat") SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
        dateString = dateFormat.format(date);
        return dateString;
    }
}
