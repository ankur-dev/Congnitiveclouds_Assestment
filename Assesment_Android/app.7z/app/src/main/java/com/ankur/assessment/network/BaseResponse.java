package com.ankur.assessment.network;

/**
 *Created by Ankur on 3/12/2016
 */
public class BaseResponse {
}
