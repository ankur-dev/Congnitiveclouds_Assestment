package com.ankur.assessment.network;

import java.io.Serializable;

/**
 * Created by Ankur on 3/12/2016.
 */
public interface DefaultNetworkResponse extends Serializable {
}
