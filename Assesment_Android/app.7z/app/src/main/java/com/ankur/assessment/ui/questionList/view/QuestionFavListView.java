package com.ankur.assessment.ui.questionList.view;

/**
 * Created by Ankur on 12/2/2016.
 */

public interface QuestionFavListView {

}
