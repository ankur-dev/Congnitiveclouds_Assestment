package com.ankur.assessment.constant;

/**
 * Created by Ankur on 12/1/2016.
 */

public class AppConstants {
    public static final int QUESTION_LIST_REQUEST_CODE = 101;
}
